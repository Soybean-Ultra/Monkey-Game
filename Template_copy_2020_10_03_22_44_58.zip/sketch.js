var gameState="play";
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score
var SurvivalTime = 20;
function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  monkey_jump = loadAnimation("sprite_3.png");
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  createCanvas(400,400);
  ground=createSprite(200,390,500,35);
  ground.shapeColor="green";
  monkey = createSprite(100,350,10,10);
monkey.addAnimation("running", monkey_running);
  monkey.addAnimation("jump",monkey_jump);
  monkey.scale=0.1;   

  FoodGroup = createGroup();
  obstacleGroup=createGroup();
}


function draw() {
background(200,200,240);
  if(gameState==="play"){
    food();
  rock();
      stroke("white")
  textSize(20);
  fill("white");
    text("Survival Time:"+ SurvivalTime,100,50);
      if(monkey.y<320){
  monkey.changeAnimation("jump",monkey_jump);
}
   if(monkey.y>320){
  monkey.changeAnimation("running",monkey_running);
}
 if(keyDown("space") && monkey.y>330){
   monkey.velocityY=-12;
 }
     if(World.frameCount%35===0){
    SurvivalTime=SurvivalTime-1;
  }
     if(monkey.collide(obstacleGroup)){
   obstacleGroup.destroyEach();
    SurvivalTime = SurvivalTime-(Math.round(SurvivalTime/10+10));
  }
     monkey.velocityY = monkey.velocityY + 0.7;
  if(monkey.collide(FoodGroup)){
    FoodGroup.destroyEach();
    SurvivalTime = SurvivalTime+7;
  }
    if(SurvivalTime<1){
      SurvivalTime=0;
      gameState="end";
    }
  }
  if(gameState==="end"){
    obstacle.velocityX=0;
    obstacle.lifetime=-1;
    banana.velocityX=0
    banana.lifetime=-1;
    monkey.changeAnimation("jump",monkey_jump);
    monkey.velocityY=0;
    monkey.velocityX=0;
     stroke("white")
  textSize(20);
  fill("white");
    text("Game Over",100,50);
  }
  
  drawSprites();

  monkey.collide(ground);
  ground.y=390;
  monkey.x=100;
}


function food(){
  if(World.frameCount % 130 === 0){
    banana = createSprite(430,200,10,10);
    banana.addImage(bananaImage);
    banana.scale=0.1;
    banana.y=Math.round(random(175,250));
    banana.velocityX=-(5+SurvivalTime/10);
    banana.lifetime=100;
  
    FoodGroup.add(banana);
  }
  
}

function rock(){
   if(World.frameCount % 160 === 0){
     obstacle=createSprite(430,350,10,10);
     obstacle.addImage(obstacleImage);
     obstacle.scale=0.15;
     obstacle.velocityX=-(7+SurvivalTime/10);
     obstacle.lifetime=100;
     
     obstacle.setCollider("circle",0,0,150);
     obstacleGroup.add(obstacle);
   }
}




